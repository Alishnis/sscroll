Edinburgh Speech Tools Library                {#mainpage}
================================

# Index

  1. @subpage estintro
  2. @subpage estlicence
  3. @subpage estexec
  4. @subpage estbaseclass
  5. @subpage estspeechclass
  6. @subpage estling
  7. @subpage estutil
  8. @subpage estsigpr
  9. @subpage estserver
  10. @subpage estgram
  11. @subpage estwagon
  12. @subpage esttilt
  13. @subpage estxml


@author Paul Taylor
@author Richard Caley
@author Alan W Black
@author Simon King


@copyright 1994-1999 Centre for Speech Technology, University of Edinburgh

